//
//  PlaySoundsViewController.swift
//  Pitch Perfect
//
//  Created by Ajay Vishwanathan on 7/11/17.
//  Copyright © 2017 Ajay Vishwanathan. All rights reserved.
//

import UIKit
import AVFoundation
class PlaySoundsViewController: UIViewController {

    @IBOutlet weak var Slow: UIButton!
    @IBOutlet weak var HighPitch: UIButton!
    @IBOutlet weak var Fast: UIButton!
    @IBOutlet weak var LowPitch: UIButton!
    @IBOutlet weak var Echo: UIButton!
    @IBOutlet weak var Reverb: UIButton!
    @IBOutlet weak var Stop: UIButton!
    
    var recordedAudioURL: NSURL!
    var audioFile:AVAudioFile!
    var audioEngine:AVAudioEngine!
    var audioPlayerNode: AVAudioPlayerNode!
    var stopTimer: NSTimer!
    
    enum ButtonType: Int {
        case slow = 0, fast, highpitch, lowpitch, echo, reverb
    }
    @IBAction func playSoundForButton( sender: UIButton)
    {
        switch(ButtonType(rawValue: sender.tag)!) {
        case .highpitch:
            playSound(pitch: 1000)
        case .lowpitch:
            playSound(pitch: -1000)
        case .echo:
            playSound(echo: true)
        case .reverb:
            playSound(reverb: true)
        case .slow:
            playSound(rate: 0.5!)
        case .fast:
            playSound(rate: 1.5!)

        }
        
        configureUI(.playing)
    }
    
    @IBAction func stopButtonPressed( sender: UIButton)
    {
        print("Stop Button Pressed")
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        configureUI(.notPlaying)
    }
    
}
